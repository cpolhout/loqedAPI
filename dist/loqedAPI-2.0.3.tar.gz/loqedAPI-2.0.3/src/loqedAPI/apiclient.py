"""Loqed: APIClient"""
import async_timeout
import logging
from .exceptions import LoqedAuthenticationException,LoqedException



logging.basicConfig(level=logging.DEBUG)


