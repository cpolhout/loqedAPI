"""Lyric: Constants"""

AUTH_URL = "https://api.honeywell.com/oauth2/authorize"
BASE_URL = "https://api.honeywell.com/v2"
TOKEN_URL = "https://api.honeywell.com/oauth2/token"