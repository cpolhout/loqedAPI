An example Python repository
----------------------------
