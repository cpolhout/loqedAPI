"""
loqedAPI.

API to integrate with the Loqed Smart Lock. Used by Home assistant integration
"""

__version__ = "0.1.0"
__author__ = 'Casper Polhout'
